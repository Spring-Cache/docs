package com.rudra.aks.controller;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.bind.annotation.RestController;

import com.rudra.aks.listener.UserMessageListener;
import com.rudra.aks.publisher.MessagePublisher;

@RestController
@RequestMapping(path="/redis")
public class RedisController {
	
	@Autowired
	MessagePublisher	publisher;
	
	@Autowired
	UserMessageListener	listener;
	
	@RequestMapping(path = "/add", method = RequestMethod.GET )
	public ResponseEntity<?> 	addMessageToQueue(@RequestParam String channel, @RequestParam String message) {
		try {
			publisher.publishMessage(channel, message);
			return new ResponseEntity<String>("message published", HttpStatus.OK);
		} catch( Exception e) { }
		return new ResponseEntity<String>("Message not published", HttpStatus.BAD_REQUEST);
	}
	
	@RequestMapping(path = "/get/{channelName}", method = RequestMethod.GET )
	public ResponseEntity<?> 	getMessageList(@PathVariable String channelName) {
		try {
			String messages = listener.messageList(channelName);
			return new ResponseEntity<>(messages, HttpStatus.OK);
		} catch( Exception e) { }
		return new ResponseEntity<String>("Message not published", HttpStatus.BAD_REQUEST);
	}
	
	@RequestMapping(path = "/listAll", method = RequestMethod.GET )
	public ResponseEntity<?> 	allChannel() {
		try {
			String messages = listener.listAll();
			return new ResponseEntity<>(messages, HttpStatus.OK);
		} catch( Exception e) { }
		return new ResponseEntity<String>("Message not published", HttpStatus.BAD_REQUEST);
	}
}
