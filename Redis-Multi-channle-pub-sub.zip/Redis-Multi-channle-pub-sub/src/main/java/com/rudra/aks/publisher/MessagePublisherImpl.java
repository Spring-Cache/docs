package com.rudra.aks.publisher;

import java.util.List;

import javax.annotation.PostConstruct;

import org.apache.log4j.Logger;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.dao.DataAccessException;
import org.springframework.data.redis.connection.RedisConnection;
import org.springframework.data.redis.core.RedisCallback;
import org.springframework.data.redis.core.RedisTemplate;
import org.springframework.data.redis.listener.ChannelTopic;
import org.springframework.data.redis.listener.Topic;
import org.springframework.data.redis.serializer.RedisSerializer;
import org.springframework.data.redis.serializer.StringRedisSerializer;
import org.springframework.stereotype.Component;

@Component
public class MessagePublisherImpl implements MessagePublisher{
	
	/*
	 * Logger
	 */
	public static final Logger logger = Logger.getLogger(MessagePublisherImpl.class);
	
	
	@Autowired
	RedisTemplate<String, Object> template;
	
	@Autowired
	ChannelTopic	topic;
	
	
	
	public void publishMessage(final String channleName, final String message) {
		logger.info("Begin : " + getClass().getName() + " : publishMessage()");
		try {
			long publishResult = template.execute(new RedisCallback<Long>() {

				@Override
				public Long doInRedis(RedisConnection connection) throws DataAccessException {
					logger.info("Subscriber List : " + connection.getClientList().toString());
					logger.info("No of client connected: " + connection.getClientList().size());
					return connection.publish(
							new StringRedisSerializer().serialize(channleName),
							new StringRedisSerializer().serialize(message));
				}
			});
			logger.info("Message published to " + channleName + " : noOfClients : " + publishResult);
		} catch (Exception e) {
			logger.info("Exception while pulishing message to channel : " + e);
		}
		/*template.convertAndSend("channel1", message+"1");
		template.convertAndSend("channel2", message+"2");*/
		
		logger.info("End : " + getClass().getName() + " : publishMessage()");
		
	}
}
