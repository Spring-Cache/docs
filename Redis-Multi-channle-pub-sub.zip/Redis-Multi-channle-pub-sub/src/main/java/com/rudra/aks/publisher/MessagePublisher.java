package com.rudra.aks.publisher;

public interface MessagePublisher {
	void publishMessage(String channleName, String message);
}
