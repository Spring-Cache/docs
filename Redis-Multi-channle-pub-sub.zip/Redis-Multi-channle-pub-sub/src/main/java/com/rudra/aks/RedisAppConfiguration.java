package com.rudra.aks;

import java.util.ArrayList;
import java.util.List;

import org.springframework.beans.factory.config.PropertyPlaceholderConfigurer;
import org.springframework.context.annotation.Bean;
import org.springframework.context.annotation.ComponentScan;
import org.springframework.context.annotation.Configuration;
import org.springframework.core.io.ClassPathResource;
import org.springframework.data.redis.connection.jedis.JedisConnectionFactory;
import org.springframework.data.redis.core.RedisTemplate;
import org.springframework.data.redis.listener.ChannelTopic;
import org.springframework.data.redis.listener.RedisMessageListenerContainer;
import org.springframework.data.redis.listener.adapter.MessageListenerAdapter;
import org.springframework.data.redis.serializer.StringRedisSerializer;

import com.rudra.aks.listener.UserMessageListener;

@Configuration
@ComponentScan(basePackages="com.rudra.aks.*")
public class RedisAppConfiguration {

	/*
	 * 
	 */
	
	@Bean
	public JedisConnectionFactory	connectionFactory() {
		JedisConnectionFactory factory = new JedisConnectionFactory();
		factory.setHostName("localhost");
		factory.setPort(6379);
		return factory;
	}
	
	@Bean
	public RedisTemplate<String, Object>	template() {
		RedisTemplate<String, Object>	template = new RedisTemplate<String, Object>();
		template.setConnectionFactory(connectionFactory());
		template.setKeySerializer(new StringRedisSerializer());
		return template;
	}
	
	/**
	 * Configuring message adapter
	 * user message listener will listener/process upon listening to any message in configured container's topic
	 * @return
	 */
	@Bean
	public MessageListenerAdapter	messageListener() {
		return new MessageListenerAdapter( new UserMessageListener());
	}
	
	@Bean
	public RedisMessageListenerContainer	listenerContainer() {
		RedisMessageListenerContainer redisContainer = new RedisMessageListenerContainer();
		redisContainer.setConnectionFactory(connectionFactory());
		redisContainer.addMessageListener(messageListener(), topicList());
		return redisContainer;
	}
	
	public List<ChannelTopic>	topicList() {
		List<ChannelTopic>	list = new ArrayList<ChannelTopic>();
		list.add(new ChannelTopic("channel1"));
		list.add(new ChannelTopic("channel2"));
		return list;
	}
	
	@Bean
	public ChannelTopic	topic() {
		return new ChannelTopic("channel: user");
	}
	
	/*
	@Bean
	public PropertyPlaceholderConfigurer	getPropertyPlaceHolderConfigurer() {
		PropertyPlaceholderConfigurer ppc = new PropertyPlaceholderConfigurer();
		ppc.setLocation(new ClassPathResource("channellist.properties"));
		ppc.setIgnoreUnresolvablePlaceholders(true);
		return ppc;
	}
	
	public List<ChannelTopic>	topicList() {
		List<ChannelTopic>	list = new ArrayList<ChannelTopic>();
		list.add(new ChannelTopic("${channel1}"));
		list.add(new ChannelTopic("${channel2}"));
		return list;
	}*/
}
