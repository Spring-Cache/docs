package com.rudra.aks.listener;

import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

import org.apache.log4j.Logger;
import org.springframework.data.redis.connection.Message;
import org.springframework.data.redis.connection.MessageListener;
import org.springframework.data.redis.serializer.StringRedisSerializer;
import org.springframework.stereotype.Component;


@Component
public class UserMessageListener implements MessageListener {

	/**
	 * Logger
	*/
	private static final Logger logger = Logger.getLogger(UserMessageListener.class);
	
	private static final String CHANNEL1 = "channel1";
	private static final String CHANNEL2 = "channel2";
	
	private static List<String>	channel1List = new ArrayList<String>();
	private static List<String>	channel2List = new ArrayList<String>();
	private	static Map<String, List<String>> channelMap = new HashMap<String, List<String>>();
	
 	@Override
	public void onMessage(Message message, byte[] pattern) {
		String serMsg = new StringRedisSerializer().deserialize(message.getBody());
		String channelName = new StringRedisSerializer().deserialize(message.getChannel());
		addToChannel(channelName, serMsg);
		
		//Add processing upon receiving message from channel pattern
		logger.info("Message Received : " + serMsg + " for channel : " + channelName);
	}

	public String messageList(String channelName) {
		if(CHANNEL1.equals(channelName))
			return channel1List.toString();
		else
			return channel2List.toString();
		
	}

	public String listAll() {
		return channelMap.toString();
	}
 	
 	private void addToChannel(String channelName, String message) {
 		if  ( CHANNEL1.equals(channelName)) { 
 			channel1List.add(message);
 			channelMap.put(CHANNEL1, channel1List);
 		}
 		else if( CHANNEL2.equals(channelName)) {
 			channel2List.add(message);
 			channelMap.put(CHANNEL2, channel2List);
 		}
 	}
}
