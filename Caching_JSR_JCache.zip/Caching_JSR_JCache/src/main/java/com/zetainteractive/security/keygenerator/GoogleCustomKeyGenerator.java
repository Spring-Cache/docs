package com.zetainteractive.security.keygenerator;

//@Component(value = "googlekeygenerator")
public class GoogleCustomKeyGenerator {//implements CacheKeyGenerator<String> {
/*
	@Override
	public String generateKey(MethodInvocation methodInvocation) {
		String methodName = methodInvocation.getMethod().getName();
		Object [] methodArgs = methodInvocation.getArguments();
		String key = null;
		if ( "saveUser".equals(methodName) || "listAllUser".equals(methodName)) 
			key = "unique_key_save";
		return key;
	}

	@Override
	public String generateKey(Object... arg0) {
		return null;
	}
*/
}
