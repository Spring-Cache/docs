package com.zetainteractive.security.test;

public class TestUser {

	public static void main(String[] args) {
		// TODO Auto-generated method stub

	}

}
